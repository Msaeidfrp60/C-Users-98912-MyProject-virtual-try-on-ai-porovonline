
import React, { createContext, useContext, useState, ReactNode, useCallback } from 'react';
import type { User } from '../types';

interface UserContextType {
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User>>;
  login: (phone: string) => void;
  logout: () => void;
  incrementUploads: () => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User>({
    isLoggedIn: false,
    uploadsUsed: 0,
    subscriptionTier: 'none',
  });

  const login = useCallback((phone: string) => {
    setUser(prev => ({
      ...prev,
      isLoggedIn: true,
      phone,
    }));
  }, []);

  const logout = useCallback(() => {
    setUser({
      isLoggedIn: false,
      uploadsUsed: 0,
      subscriptionTier: 'none',
    });
  }, []);
  
  const incrementUploads = useCallback(() => {
    setUser(prev => ({
      ...prev,
      uploadsUsed: prev.uploadsUsed + 1
    }));
  }, []);

  return (
    <UserContext.Provider value={{ user, setUser, login, logout, incrementUploads }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}

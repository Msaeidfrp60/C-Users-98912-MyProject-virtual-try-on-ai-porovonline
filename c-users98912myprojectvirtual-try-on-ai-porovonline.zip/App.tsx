
import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { UserProvider } from './contexts/UserContext';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import Subscription from './components/Subscription';
import Support from './components/Support';
import Profile from './components/Profile';

function App() {
  return (
    <UserProvider>
      <Router>
        <div style={{ minHeight: '100vh', backgroundColor: '#F9FAFB' }}>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/subscription" element={<Subscription />} />
            <Route path="/support" element={<Support />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </div>
      </Router>
    </UserProvider>
  );
}

export default App;


export type SubscriptionTier = 'none' | 'monthly' | 'sixmonth' | 'yearly';

export interface User {
  isLoggedIn: boolean;
  phone?: string;
  name?: string;
  lastName?: string;
  uploadsUsed: number;
  subscriptionTier: SubscriptionTier;
  subscriptionEndDate?: Date;
}

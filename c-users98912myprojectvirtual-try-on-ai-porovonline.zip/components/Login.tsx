
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../contexts/UserContext';
import { HangerIcon } from './icons/HangerIcon';
import { WhatsAppIcon } from './icons/WhatsAppIcon';
import { PhoneIcon } from './icons/PhoneIcon';
import { STYLES, COLORS } from '../constants';

export default function Login() {
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { login } = useUser();

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone.match(/^\d{10}$/)) {
      setError('شماره موبایل باید ۱۰ رقم بدون صفر اول باشد');
      return;
    }
    setError('');
    setIsLoading(true);

    await new Promise(resolve => setTimeout(resolve, 1000));
    console.log(`Mock OTP for +98${phone}: 123456`);

    setIsLoading(false);
    setStep(2);
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length < 4) {
      setError('کد وارد شده صحیح نیست');
      return;
    }
    setError('');
    setIsLoading(true);

    await new Promise(resolve => setTimeout(resolve, 1000));
    const isSuccess = otp === '123456';

    setIsLoading(false);
    if (isSuccess) {
      login(`+98${phone}`);
      navigate('/dashboard');
    } else {
      setError('کد وارد شده اشتباه است');
    }
  };

  return (
    <div style={STYLES.container}>
      <div style={{...STYLES.card, textAlign: 'center'}}>
        <div style={{ width: '80px', height: '80px', margin: '0 auto 1.5rem', color: COLORS.primary }}>
          <HangerIcon />
        </div>
        
        <h1 style={{ fontSize: '2rem', fontWeight: 'bold', color: COLORS.primary, marginBottom: '0.5rem' }}>پرو مجازی</h1>
        <p style={{ color: COLORS.textSecondary, marginBottom: '0.5rem' }}>لباس های خود را قبل از خرید، به صورت مجازی امتحان کنید</p>
        <p style={{ color: COLORS.textMuted, marginBottom: '2rem' }}>قبل از مهمانی لباس های خود را پرو کنید</p>

        {step === 1 ? (
          <form onSubmit={handleSendOtp}>
            <div style={{ position: 'relative', marginBottom: '1rem' }}>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/[^0-9]/g, ''))}
                maxLength={10}
                style={{ ...STYLES.inputField, paddingLeft: '40px', direction: 'ltr', textAlign: 'right' }}
                placeholder="9123456789"
              />
              <span style={{ position: 'absolute', left: '19px', top: '40%', transform: 'translateY(-50%)', color: COLORS.textMuted }}>98+</span>
            </div>
            <button
              type="submit"
              disabled={isLoading}
              style={{...STYLES.btnPrimary, opacity: isLoading ? 0.7 : 1, width: '50%', margin: '0 auto'}}
            >
              {isLoading ? 'در حال ارسال...' : 'ارسال کد'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleVerifyOtp}>
            <p style={{ color: COLORS.textSecondary, marginBottom: '1rem' }}>
              کد تایید به شماره <span style={{ fontWeight: 600, direction: 'ltr', display: 'inline-block' }}>+98 {phone}</span> ارسال شد
            </p>
            <input
              type="text"
              inputMode="numeric"
              value={otp}
              onChange={(e) => setOtp(e.target.value.replace(/[^0-9]/g, ''))}
              maxLength={6}
              style={{ ...STYLES.inputField, textAlign: 'center', fontSize: '1.5rem', letterSpacing: '0.5em', marginBottom: '1rem' }}
              placeholder="- - - - - -"
            />
            <button type="submit" disabled={isLoading} style={{...STYLES.btnPrimary, opacity: isLoading ? 0.7 : 1, marginBottom: '0.5rem' }}>
              {isLoading ? 'در حال بررسی...' : 'ورود'}
            </button>
            <button type="button" onClick={() => { setStep(1); setError(''); setOtp(''); }} style={{...STYLES.btnSecondary, border: 'none', background: 'transparent', color: COLORS.textMuted, width: 'auto' }}>
              ویرایش شماره موبایل
            </button>
          </form>
        )}

        {error && <p style={{ color: COLORS.danger, marginTop: '1rem' }}>{error}</p>}
        
        <div style={{ marginTop: '3rem', paddingTop: '1.5rem', borderTop: `1px solid ${COLORS.secondary}` }}>
          <p style={{ fontWeight: 600, marginBottom: '0.5rem' }}>پشتیبانی</p>
          <p style={{ fontSize: '0.8rem', color: COLORS.textMuted, marginBottom: '1rem' }}>
            در صورت بروز هرگونه مشکل یا سوال، می‌توانید از طریق راه‌های زیر با ما در تماس باشید
          </p>
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '2rem' }}>
            <a href="https://wa.me/989120137032" target="_blank" rel="noopener noreferrer" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textDecoration: 'none', color: '#25D366' }}>
              <WhatsAppIcon />
              <span style={{ fontSize: '0.75rem', marginTop: '0.25rem' }}>واتس‌اپ</span>
            </a>
            <a href="tel:+989120137032" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textDecoration: 'none', color: '#3B82F6' }}>
              <PhoneIcon />
              <span style={{ fontSize: '0.75rem', marginTop: '0.25rem' }}>تماس</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}


import React from 'react';

export const HangerIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M13.5 8.5a3 3 0 10-3 0" />
    <path d="M10.5 6V3.5a1.5 1.5 0 013 0V6" />
    <path d="M4 8.5h16" />
    <path d="M4 8.5L8 18" />
    <path d="M20 8.5L16 18" />
  </svg>
);

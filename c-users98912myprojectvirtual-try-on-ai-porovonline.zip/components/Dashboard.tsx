
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useUser } from '../contexts/UserContext';
import { HangerIcon } from './icons/HangerIcon';
import { STYLES, COLORS } from '../constants';
import { generateVirtualTryOn } from '../services/geminiService';

const FREE_UPLOAD_LIMIT = 10;

const ImageUploadStep: React.FC<{ title: string; description: string; onFileSelect: (file: File) => void; selectedFile: File | null; id: string; }> = ({ title, description, onFileSelect, selectedFile, id }) => (
    <div>
        <h2 style={{ fontSize: '1.125rem', fontWeight: 600, marginBottom: '1rem' }}>{title}</h2>
        <p style={{ color: COLORS.textMuted, marginBottom: '1rem', fontSize: '0.9rem' }}>{description}</p>
        <label htmlFor={id} style={{ ...STYLES.btnSecondary, display: 'block', cursor: 'pointer', marginBottom: '1rem', textAlign: 'center' }}>
            انتخاب عکس
        </label>
        <input
            id={id}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={(e) => e.target.files && onFileSelect(e.target.files[0])}
            style={{ display: 'none' }}
        />
        {selectedFile && <p style={{ color: COLORS.success, marginBottom: '1rem', textAlign: 'center', fontWeight: 500 }}>✓ {selectedFile.name}</p>}
    </div>
);


const ResultView: React.FC<{ resultImage: string; onReset: () => void }> = ({ resultImage, onReset }) => (
    <div style={{ textAlign: 'center' }}>
        <h2 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '1rem', color: COLORS.primary }}>پرو مجازی شما آماده است!</h2>
        <img src={resultImage} alt="Virtual Try-On Result" style={{ maxWidth: '100%', borderRadius: '8px', marginBottom: '1.5rem', border: `1px solid ${COLORS.secondary}` }} />
        <button onClick={onReset} style={STYLES.btnPrimary}>
            ایجاد یک پرو جدید
        </button>
    </div>
);


export default function Dashboard() {
    const { user, logout, incrementUploads } = useUser();
    const navigate = useNavigate();
    
    const [modelPhoto, setModelPhoto] = useState<File | null>(null);
    const [clothPhoto, setClothPhoto] = useState<File | null>(null);
    const [error, setError] = useState('');
    const [showLimitPopup, setShowLimitPopup] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [resultImage, setResultImage] = useState<string | null>(null);

    useEffect(() => {
        if (!user.isLoggedIn) {
            navigate('/login');
        }
    }, [user.isLoggedIn, navigate]);

    const handleCreate = async () => {
        if (!modelPhoto || !clothPhoto) {
            setError('لطفاً هر دو عکس را آپلود کنید.');
            return;
        }

        if (user.uploadsUsed >= FREE_UPLOAD_LIMIT && user.subscriptionTier === 'none') {
            setShowLimitPopup(true);
            return;
        }

        setError('');
        setIsLoading(true);
        try {
            const generatedImage = await generateVirtualTryOn(modelPhoto, clothPhoto);
            setResultImage(generatedImage);
            incrementUploads();
        } catch (err: any) {
            setError(err.message || 'خطایی در ایجاد تصویر رخ داد.');
        } finally {
            setIsLoading(false);
        }
    };

    const resetState = () => {
        setModelPhoto(null);
        setClothPhoto(null);
        setResultImage(null);
        setError('');
    };

    if (!user.isLoggedIn) {
        return null; 
    }
    
    return (
        <div style={STYLES.container}>
            <div style={STYLES.card}>
                <div style={{ display: 'flex', alignItems: 'center', marginBottom: '1.5rem' }}>
                    <div style={{ width: '48px', height: '48px', color: COLORS.primary, marginRight: '12px' }}>
                        <HangerIcon />
                    </div>
                    <div>
                        <h1 style={{ fontSize: '1.25rem', fontWeight: 'bold', color: COLORS.primary }}>پرو مجازی</h1>
                        <p style={{ color: COLORS.textMuted }}>{resultImage ? 'نتیجه' : 'داشبورد'}</p>
                    </div>
                </div>

                {isLoading ? (
                    <div style={{padding: '4rem 0'}}>
                        <div style={STYLES.spinner}>
                          <style>{`@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }`}</style>
                        </div>
                        <p style={{textAlign: 'center', color: COLORS.textMuted, marginTop: '1rem'}}>در حال پردازش... این ممکن است کمی طول بکشد.</p>
                    </div>
                ) : resultImage ? (
                    <ResultView resultImage={resultImage} onReset={resetState} />
                ) : (
                    <div>
                        <ImageUploadStep
                            id="model-upload"
                            title="مرحله ۱: عکس خود را وارد کنید"
                            description="یک عکس واضح از روبرو که تمام بدن شما مشخص باشد آپلود کنید."
                            selectedFile={modelPhoto}
                            onFileSelect={setModelPhoto}
                        />
                        <hr style={{ border: 'none', borderTop: `1px solid ${COLORS.secondary}`, margin: '1.5rem 0' }} />
                        <ImageUploadStep
                            id="cloth-upload"
                            title="مرحله ۲: عکس لباس را وارد کنید"
                            description="عکس با پس‌زمینه ساده از لباس مورد نظر را انتخاب کنید."
                            selectedFile={clothPhoto}
                            onFileSelect={setClothPhoto}
                        />

                        <button
                            onClick={handleCreate}
                            disabled={!modelPhoto || !clothPhoto}
                            style={{...STYLES.btnPrimary, marginTop: '1.5rem', opacity: (!modelPhoto || !clothPhoto) ? 0.5 : 1, cursor: (!modelPhoto || !clothPhoto) ? 'not-allowed' : 'pointer'}}
                        >
                            ایجاد پرو مجازی
                        </button>
                    </div>
                )}
                 {error && <p style={{ color: COLORS.danger, marginTop: '1rem', textAlign: 'center' }}>{error}</p>}
            </div>

            <div style={{ display: 'grid', gap: '1rem' }}>
                <Link to="/subscription" style={STYLES.linkCard}>
                    <h3 style={{ fontWeight: 600, color: COLORS.primary, marginBottom: '0.5rem' }}>اشتراک‌ها</h3>
                    <p style={{ color: COLORS.textMuted, fontSize: '0.875rem' }}>مشاهده پلن‌های اشتراک و کد تخفیف</p>
                </Link>

                <Link to="/support" style={STYLES.linkCard}>
                    <h3 style={{ fontWeight: 600, color: COLORS.primary, marginBottom: '0.5rem' }}>پشتیبانی</h3>
                    <p style={{ color: COLORS.textMuted, fontSize: '0.875rem' }}>تماس با پشتیبانی</p>
                </Link>

                <Link to="/profile" style={STYLES.linkCard}>
                    <h3 style={{ fontWeight: 600, color: COLORS.primary, marginBottom: '0.5rem' }}>پروفایل</h3>
                    <p style={{ color: COLORS.textMuted, fontSize: '0.875rem' }}>ویرایش اطلاعات شخصی</p>
                </Link>

                <button onClick={logout} style={{ ...STYLES.card, width: '100%', border: 'none', textAlign: 'right', cursor: 'pointer', background: 'transparent', boxShadow: 'none', padding: '16px' }}>
                    <h3 style={{ fontWeight: 600, color: COLORS.danger, margin: 0 }}>خروج از حساب</h3>
                </button>
            </div>

            {showLimitPopup && (
                <div style={STYLES.popupOverlay}>
                    <div style={STYLES.popup}>
                        <h3 style={{ fontWeight: 600, marginBottom: '1rem', fontSize: '1.125rem' }}>محدودیت استفاده رایگان!</h3>
                        <p style={{ color: COLORS.textMuted, marginBottom: '1.5rem' }}>تعداد ۱۰ پرو مجازی رایگان شما به پایان رسیده است. برای ادامه، یکی از پلن‌ها را انتخاب کنید.</p>
                        <Link to="/subscription" style={{...STYLES.btnPrimary, display: 'inline-block', marginBottom: '0.5rem'}}>خرید اشتراک</Link>
                        <button onClick={() => setShowLimitPopup(false)} style={{...STYLES.btnSecondary, background: 'transparent', border: 'none', width: 'auto' }}>بستن</button>
                    </div>
                </div>
            )}
        </div>
    );
}

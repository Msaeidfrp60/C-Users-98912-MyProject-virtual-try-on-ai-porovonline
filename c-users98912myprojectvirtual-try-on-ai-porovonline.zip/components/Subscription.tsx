
import React from 'react';
import { Link } from 'react-router-dom';
import { STYLES, COLORS } from '../constants';

const SubscriptionPlan: React.FC<{ title: string; price: string; features: string[]; isPopular?: boolean }> = ({ title, price, features, isPopular }) => (
    <div style={{ ...STYLES.card, border: isPopular ? `2px solid ${COLORS.primary}` : `1px solid ${COLORS.secondary}`, position: 'relative' }}>
        {isPopular && <div style={{ position: 'absolute', top: '-15px', right: '20px', background: COLORS.primary, color: COLORS.white, padding: '4px 12px', borderRadius: '12px', fontSize: '0.8rem', fontWeight: 600 }}>محبوب ترین</div>}
        <h3 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '0.5rem', color: COLORS.primary }}>{title}</h3>
        <p style={{ fontSize: '1.75rem', fontWeight: 700, marginBottom: '1rem' }}>{price}</p>
        <ul style={{ listStyle: 'none', padding: 0, marginBottom: '1.5rem', textAlign: 'right' }}>
            {features.map((feature, index) => (
                <li key={index} style={{ marginBottom: '0.5rem', color: COLORS.textSecondary }}>✓ {feature}</li>
            ))}
        </ul>
        <button style={STYLES.btnPrimary}>انتخاب پلن</button>
    </div>
);

export default function Subscription() {
  return (
    <div style={STYLES.container}>
      <h1 style={{ textAlign: 'center', fontSize: '1.5rem', fontWeight: 700, color: COLORS.textPrimary, marginBottom: '2rem' }}>پلن‌های اشتراک</h1>
      
      <div style={{ display: 'grid', gap: '1.5rem' }}>
        <SubscriptionPlan 
            title="ماهانه"
            price="۹۹٬۰۰۰ تومان"
            features={['۵۰ پرو مجازی در ماه', 'پشتیبانی تیکتینگ']}
        />
         <SubscriptionPlan 
            title="شش ماهه"
            price="۴۹۹٬۰۰۰ تومان"
            features={['۳۰۰ پرو مجازی', 'صرفه‌جویی ۱۰٪', 'پشتیبانی ویژه']}
            isPopular={true}
        />
         <SubscriptionPlan 
            title="سالیانه"
            price="۸۹۹٬۰۰۰ تومان"
            features={['۷۰۰ پرو مجازی', 'صرفه‌جویی ۲۰٪', 'بالاترین اولویت پشتیبانی']}
        />
      </div>
      
      <div style={{ textAlign: 'center', marginTop: '2rem' }}>
        <Link to="/dashboard" style={STYLES.btnSecondary}>بازگشت به داشبورد</Link>
      </div>
    </div>
  );
}

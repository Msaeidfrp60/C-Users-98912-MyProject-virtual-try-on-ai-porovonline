
import React from 'react';
import { Link } from 'react-router-dom';
import { useUser } from '../contexts/UserContext';
import { STYLES, COLORS } from '../constants';

export default function Profile() {
  const { user } = useUser();

  return (
    <div style={STYLES.container}>
        <div style={STYLES.card}>
            <h1 style={{ textAlign: 'center', fontSize: '1.5rem', fontWeight: 700, color: COLORS.textPrimary, marginBottom: '2rem' }}>پروفایل کاربری</h1>
            
            <form>
                <div style={{ marginBottom: '1rem' }}>
                    <label style={{ display: 'block', marginBottom: '0.5rem', color: COLORS.textSecondary, fontSize: '0.9rem' }}>شماره موبایل</label>
                    <input 
                        type="text" 
                        value={user.phone || ''} 
                        readOnly 
                        style={{ ...STYLES.inputField, backgroundColor: COLORS.secondary, cursor: 'not-allowed', direction: 'ltr' }}
                    />
                </div>
                 <div style={{ marginBottom: '1rem' }}>
                    <label htmlFor="name" style={{ display: 'block', marginBottom: '0.5rem', color: COLORS.textSecondary, fontSize: '0.9rem' }}>نام</label>
                    <input id="name" type="text" placeholder="نام خود را وارد کنید" style={STYLES.inputField} />
                </div>
                 <div style={{ marginBottom: '1.5rem' }}>
                    <label htmlFor="lastname" style={{ display: 'block', marginBottom: '0.5rem', color: COLORS.textSecondary, fontSize: '0.9rem' }}>نام خانوادگی</label>
                    <input id="lastname" type="text" placeholder="نام خانوادگی خود را وارد کنید" style={STYLES.inputField} />
                </div>
                <button type="submit" style={STYLES.btnPrimary}>ذخیره تغییرات</button>
            </form>
        </div>

        <div style={{ textAlign: 'center', marginTop: '2rem' }}>
            <Link to="/dashboard" style={STYLES.btnSecondary}>بازگشت به داشبورد</Link>
        </div>
    </div>
  );
}

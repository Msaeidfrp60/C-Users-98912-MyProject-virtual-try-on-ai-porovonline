
import React from 'react';
import { Link } from 'react-router-dom';
import { STYLES, COLORS } from '../constants';
import { WhatsAppIcon } from './icons/WhatsAppIcon';
import { PhoneIcon } from './icons/PhoneIcon';

export default function Support() {
  return (
    <div style={STYLES.container}>
        <div style={STYLES.card}>
            <h1 style={{ textAlign: 'center', fontSize: '1.5rem', fontWeight: 700, color: COLORS.textPrimary, marginBottom: '1rem' }}>پشتیبانی</h1>
            <p style={{ textAlign: 'center', color: COLORS.textMuted, marginBottom: '2rem' }}>برای دریافت پشتیبانی می‌توانید از راه‌های زیر با ما در تماس باشید.</p>

             <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '2rem' }}>
                <a href="https://wa.me/989120137032" target="_blank" rel="noopener noreferrer" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textDecoration: 'none', color: '#25D366' }}>
                <WhatsAppIcon />
                <span style={{ fontSize: '0.75rem', marginTop: '0.25rem' }}>واتس‌اپ</span>
                </a>
                <a href="tel:+989120137032" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textDecoration: 'none', color: '#3B82F6' }}>
                <PhoneIcon />
                <span style={{ fontSize: '0.75rem', marginTop: '0.25rem' }}>تماس</span>
                </a>
            </div>
        </div>

        <div style={{ textAlign: 'center', marginTop: '2rem' }}>
            <Link to="/dashboard" style={STYLES.btnSecondary}>بازگشت به داشبورد</Link>
        </div>
    </div>
  );
}
